Subir aquí tus capturas con estos nombres (el README ya las referencia):
- fortigate_interfaces.png
- fortigate_vpn.png
- ping_exitoso.png
Opcionales: fortigate_fase1.png, fortigate_fase2.png, fortigate_politicas.png, r1_crypto_sa.png, vpn_caida.png
