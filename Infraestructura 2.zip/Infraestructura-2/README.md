# Laboratorio: VPN Sitio a Sitio (FortiGate ↔ Cisco)

## 🎥 Video Demostrativo
El enlace al video demostrativo está en el archivo [`video.txt`](video.txt).

---

## 🎯 Propósito del Laboratorio
Implementar una VPN IPsec sitio a sitio entre un cortafuegos **FortiGate** (configurado por interfaz gráfica) y un router **Cisco** de otro fabricante, usando un router ISP como intermediario con direccionamiento público. Se demuestra que el usuario (VLAN 10) llega al servidor web HTTPS únicamente a través del túnel, y que si el túnel está caído la comunicación no fluye.

---

## 🗺️ Diagramas

![Diagrama conceptual](imagenes/diagrama_conceptual.png)
*Figura 1: Diagrama conceptual.*

![Topología del Laboratorio](imagenes/topologia.png)
*Figura 2: Topología implementada en GNS3, con interfaces y direccionamiento.*

![Flujo de la VPN](imagenes/diagrama_vpn.png)
*Figura 3: Flujo lógico de la VPN.*

**Descripción de los equipos:**
- **ISP (Router Cisco c7200):** simula Internet y entrega las redes públicas 200.2.2.0/30 (hacia R1) y 200.1.2.0/30 (hacia el FortiGate).
- **R1 (Router Cisco c7200):** sede de los usuarios. Hace el enrutamiento entre VLAN (router-on-a-stick), DHCP, NAT y es uno de los extremos de la VPN.
- **Switch1 (conmutador de GNS3):** acceso de la VLAN 10. e0 es troncal hacia R1 y e1 es acceso VLAN 10 hacia PC1.
- **FortiGate 7.0.9:** cortafuegos perimetral de la red del servidor (configuración por GUI) y el otro extremo de la VPN.
- **UbuntuDesktop 24:** servidor web HTTPS en la red 192.168.14.0/28.
- **PC1 (VPCS):** usuario final en la VLAN 10 (red 192.168.10.0/30).

**Direccionamiento:**

| Enlace | Red | Extremo A | Extremo B |
|---|---|---|---|
| ISP – R1 | 200.2.2.0/30 | ISP f1/0 · 200.2.2.1 | R1 f1/0 · 200.2.2.2 |
| ISP – FortiGate | 200.1.2.0/30 | ISP f0/0 · 200.1.2.1 | FortiGate Port1 · 200.1.2.2 |
| Usuarios VLAN 10 | 192.168.10.0/30 | R1 f0/0.10 · 192.168.10.1 | PC1 · 192.168.10.2 (DHCP) |
| Servidor | 192.168.14.0/28 | FortiGate Port2 · 192.168.14.1 | Servidor · 192.168.14.2 |

**Parámetros de la VPN:** IKEv1 modo principal, AES-256, SHA-256, DH 14, clave precompartida (fase 1, 28800 s); ESP AES-256/SHA-256 con PFS 14 (fase 2, 43200 s). Tráfico protegido: 192.168.10.0/30 ↔ 192.168.14.0/28.

---

## 📸 Documentación con Imágenes

### Configuración de interfaces en el FortiGate
![Interfaces FortiGate](imagenes/fortigate_interfaces.png)
*Figura 4: Interfaces WAN (Port1) y LAN (Port2) en la interfaz gráfica del FortiGate.*

### Túnel VPN
![Túnel VPN](imagenes/fortigate_vpn.png)
*Figura 5: Estado del túnel VPN sitio a sitio en el Monitor de IPsec del FortiGate.*

### Verificación de conectividad
![Ping exitoso](imagenes/ping_exitoso.png)
*Figura 6: Prueba exitosa desde PC1 hacia el servidor Ubuntu a través de la VPN.*

---

## ⚙️ Configuraciones (Running-Configs)

Los archivos completos están en la carpeta [`configuraciones/`](configuraciones/).

### 1. Router Cisco R1
Archivo: [`configuraciones/R1.txt`](configuraciones/R1.txt)
```cisco
interface FastEthernet1/0
 ip address 200.2.2.2 255.255.255.252
 ip nat outside
 crypto map VPN-FORTIGATE
!
interface FastEthernet0/0.10
 encapsulation dot1Q 10
 ip address 192.168.10.1 255.255.255.252
 ip nat inside
!
ip route 0.0.0.0 0.0.0.0 200.2.2.1
!
crypto isakmp policy 10
 encryption aes 256
 hash sha256
 authentication pre-share
 group 14
!
crypto map VPN-FORTIGATE 10 ipsec-isakmp
 set peer 200.1.2.2
 set transform-set TS-AES256
 set pfs group14
 match address VPN-INTERESANTE
```

### 2. Router ISP
Archivo: [`configuraciones/ISP.txt`](configuraciones/ISP.txt)
```cisco
hostname ISP
!
interface FastEthernet0/0
 ip address 200.1.2.1 255.255.255.252
 no shutdown
!
interface FastEthernet1/0
 ip address 200.2.2.1 255.255.255.252
 no shutdown
```

### 3. FortiGate
Archivo: [`configuraciones/FortiGate.conf`](configuraciones/FortiGate.conf)
```text
config system interface
    edit "port1"
        set ip 200.1.2.2 255.255.255.252
    next
    edit "port2"
        set ip 192.168.14.1 255.255.255.240
    next
end

config vpn ipsec phase1-interface
    edit "VPN-A-R1"
        set interface "port1"
        set remote-gw 200.2.2.2
        set proposal aes256-sha256
        set dhgrp 14
    next
end
```

### 4. Switch1 (VLAN 10)
Archivo: [`configuraciones/Switch1.txt`](configuraciones/Switch1.txt)

| Puerto | Tipo | VLAN | Conectado a |
|---|---|---|---|
| Ethernet0 | dot1q (troncal) | 1 | R1 f0/0 |
| Ethernet1 | access | 10 | PC1 |

### 5. Servidor Ubuntu
Archivo: [`configuraciones/Servidor-Ubuntu.txt`](configuraciones/Servidor-Ubuntu.txt)
```text
Dirección IP:      192.168.14.2/28
Puerta de enlace:  192.168.14.1
```

---

## 📜 Scripts Utilizados
Todos los scripts están en la carpeta [`scripts/`](scripts/) (ver [`scripts/README.md`](scripts/README.md)):

- [`R1-vpn.txt`](scripts/R1-vpn.txt): configuración completa de R1 (VLAN 10, DHCP, NAT y VPN).
- [`ISP.txt`](scripts/ISP.txt): interfaces del ISP.
- [`PC1-vpcs.txt`](scripts/PC1-vpcs.txt): DHCP y pruebas desde PC1.
- [`servidor-https.sh`](scripts/servidor-https.sh): IP estática y servidor Apache con HTTPS.
- [`configuracion-fortigate-gui.md`](scripts/configuracion-fortigate-gui.md): pasos de la configuración del FortiGate por GUI.

El proyecto de GNS3 está en [`proyecto-gns3/`](proyecto-gns3/).
