#!/bin/bash
# Servidor Web HTTPS (Ubuntu Desktop 24) - IP 192.168.14.2/28, puerta de enlace 192.168.14.1
# Ejecutar con: sudo bash servidor-https.sh
set -e

# 1) Direccionamiento estatico (cambiar "Wired connection 1" si el nombre difiere: nmcli con show)
nmcli con mod "Wired connection 1" ipv4.method manual \
  ipv4.addresses 192.168.14.2/28 ipv4.gateway 192.168.14.1 ipv4.dns 8.8.8.8
nmcli con up "Wired connection 1"

# 2) Apache con HTTPS y certificado autofirmado
apt update && apt install -y apache2 openssl
mkdir -p /etc/ssl/lab
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/lab/servidor.key -out /etc/ssl/lab/servidor.crt \
  -subj "/C=DO/O=Laboratorio VPN/CN=192.168.14.2"
a2enmod ssl
sed -i 's#/etc/ssl/certs/ssl-cert-snakeoil.pem#/etc/ssl/lab/servidor.crt#; s#/etc/ssl/private/ssl-cert-snakeoil.key#/etc/ssl/lab/servidor.key#' \
  /etc/apache2/sites-available/default-ssl.conf
a2ensite default-ssl
echo "<h1>Servidor Web HTTPS - Infraestructura 2</h1>" > /var/www/html/index.html
systemctl restart apache2
systemctl enable apache2

# 3) Verificacion local
curl -k https://192.168.14.2
