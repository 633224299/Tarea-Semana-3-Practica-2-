# Scripts utilizados

| Archivo | Equipo | Descripción |
|---|---|---|
| `R1-vpn.txt` | R1 (Cisco) | Interfaces, router-on-a-stick VLAN 10, DHCP, NAT y VPN IPsec |
| `ISP.txt` | ISP (Cisco) | Interfaces públicas hacia R1 y FortiGate |
| `PC1-vpcs.txt` | PC1 (VPCS) | DHCP y pruebas de conectividad |
| `servidor-https.sh` | Servidor Ubuntu | IP estática y Apache con HTTPS |
| `configuracion-fortigate-gui.md` | FortiGate | Guía paso a paso de la configuración por interfaz gráfica |
