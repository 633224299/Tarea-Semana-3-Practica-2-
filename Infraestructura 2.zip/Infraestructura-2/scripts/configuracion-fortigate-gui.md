# Configuración del FortiGate por interfaz gráfica (GUI)

Acceso: `https://<IP de administración del Port2>` — usuario `admin`.
Los nombres de menú se escriben como aparecen en la interfaz en español.

## 1. Interfaces — Red > Interfaces
| Interfaz | Rol | Dirección IP | Acceso administrativo |
|---|---|---|---|
| Port1 | WAN | 200.1.2.2/30 | PING |
| Port2 | LAN | 192.168.14.1/28 | HTTPS, PING, SSH |

## 2. Ruta por defecto — Red > Rutas estáticas > Crear nuevo
- Destino: `0.0.0.0/0`
- Puerta de enlace: `200.1.2.1`
- Interfaz: `Port1`

## 3. Objetos de direcciones — Política y objetos > Direcciones
- `RED-USUARIOS` → subred `192.168.10.0/30`
- `RED-SERVIDOR` → subred `192.168.14.0/28`

## 4. Túnel VPN — VPN > Túneles IPsec > Crear nuevo > Personalizado
**Fase 1**
- Nombre: `VPN-A-R1`
- Puerta de enlace remota: IP estática `200.2.2.2`, interfaz `Port1`
- Modo: Principal · Autenticación: Clave precompartida (la misma que en R1)
- Versión IKE: 1 · Cifrado AES256 · Autenticación SHA256 · Grupo DH 14 · Duración de la clave 28800

**Fase 2**
- Dirección local: `192.168.14.0/28` · Dirección remota: `192.168.10.0/30`
- Cifrado AES256 · Autenticación SHA256 · PFS activado, grupo 14 · Duración 43200

## 5. Ruta hacia la red remota — Red > Rutas estáticas
- Destino: `192.168.10.0/30` · Interfaz: `VPN-A-R1`
- Crear además una ruta *blackhole* a la misma red con distancia mayor, para que el tráfico no salga por Internet si el túnel cae.

## 6. Políticas de cortafuegos — Política y objetos > Política de cortafuegos
| Nombre | Entrada | Salida | Origen | Destino | NAT |
|---|---|---|---|---|---|
| LAN-a-VPN | Port2 | VPN-A-R1 | RED-SERVIDOR | RED-USUARIOS | Desactivado |
| VPN-a-LAN | VPN-A-R1 | Port2 | RED-USUARIOS | RED-SERVIDOR | Desactivado |
| LAN-a-Internet | Port2 | Port1 | RED-SERVIDOR | all | Activado |

## 7. Verificación — Panel de control > Monitor de IPsec
El túnel debe aparecer **Activo** (verde) tras generar tráfico desde PC1.
