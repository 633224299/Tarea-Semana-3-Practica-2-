#!/bin/bash
# Servidor web HTTPS (Apache) + SSH
set -e
sudo apt update
sudo apt install apache2 openssh-server -y

sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/private/servidor.key \
  -out /etc/ssl/certs/servidor.crt

sudo a2enmod ssl
sudo a2ensite default-ssl
sudo sed -i 's#/etc/ssl/certs/ssl-cert-snakeoil.pem#/etc/ssl/certs/servidor.crt#; s#/etc/ssl/private/ssl-cert-snakeoil.key#/etc/ssl/private/servidor.key#' /etc/apache2/sites-available/default-ssl.conf
echo "<h1>Servidor Web - Infraestructura 3</h1>" | sudo tee /var/www/html/index.html

sudo systemctl enable --now apache2 ssh
sudo systemctl restart apache2

# Verificación
ss -tlnp | grep -E ':22|:443'
curl -k https://localhost
