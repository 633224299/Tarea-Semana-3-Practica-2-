# Infraestructura 3 — VPN de acceso remoto con FortiGate

> 🎥 **Video demostrativo:** <PEGAR_ENLACE_DE_YOUTUBE>

## Propósito

Implementar una infraestructura donde un **usuario** (red /25, VLAN 10, DHCP) accede a un **servidor web** (red /28) a través de un ISP y un **FortiGate**, cumpliendo que:

- El usuario accede al **servidor web (HTTPS) sin necesidad de VPN**.
- El usuario accede al servidor por **SSH únicamente a través de la VPN** de acceso remoto (VPN SSL).
- Toda la configuración y demostración del FortiGate se realiza **por interfaz gráfica**.

## Topología

```mermaid
flowchart LR
    U[Usuario<br/>Ubuntu Desktop<br/>VLAN 10 /25] --- SW[Switch1]
    SW --- R2[R2<br/>Equipo de red Cisco]
    R2 --- R1[R1<br/>ISP]
    R1 --- FG[FortiGate]
    FG --- S[Servidor Web<br/>Ubuntu Desktop /28]
```

![Topología GNS3](imagenes/topologia.png)


## Equipos

| Equipo | Rol | Plataforma |
|---|---|---|
| Ubuntu Desktop 24 (usuario) | Cliente, VLAN 10, cliente VPN (FortiClient) | VMware |
| Switch1 | Conmutador: acceso VLAN 10 hacia el usuario, troncal hacia R2 | GNS3 |
| R2 | Equipo de red Cisco: puerta de enlace VLAN 10, servidor DHCP | Cisco c7200 |
| R1 | ISP: direccionamiento y enrutamiento | Cisco c7200 |
| FortiGate | Cortafuegos, IP virtual, VPN SSL (todo por GUI) | FortiGate 7.0.9 |
| Ubuntu Desktop 24 (servidor) | Servidor web HTTPS y SSH | VMware |

## Direccionamiento

| Segmento | Red | Equipo / Interfaz | Dirección |
|---|---|---|---|
| Usuarios (VLAN 10) | `10.10.10.0/25` | R2 `f0/0.1` (puerta de enlace) | `10.10.10.1` |
| | | Usuario (DHCP) | `10.10.10.2` |
| R2 ↔ R1 | `10.10.50.0/28` | R2 `f1/0` | `10.10.50.1` |
| | | R1 `f1/0` | `10.10.50.2` |
| R1 ↔ FortiGate (ISP) | `10.10.52.0/28` | R1 `f0/0` | `10.10.52.1` |
| | | FortiGate `Port1` | `10.10.52.2` |
| Servidor | `192.168.1.0/28` | FortiGate `Port2` | `192.168.1.1` |
| | | Servidor | `<IP_SERVIDOR>` |
| Clientes VPN SSL | `<RANGO_VPN>` | Túnel `ssl.root` | — |

## Configuración

### 1. Equipo de red (R2) y ISP (R1)
Scripts: [`scripts/R2.txt`](scripts/R2.txt) y [`scripts/R1.txt`](scripts/R1.txt).

- R2: subinterfaz `f0/0.1` con encapsulación dot1Q (VLAN 10), servidor DHCP para el /25 y ruta por defecto hacia R1.
- R1: interfaces del ISP y ruta hacia la red de usuarios a través de R2.

### 2. Servidor
Script: [`scripts/servidor.sh`](scripts/servidor.sh). Instala Apache con HTTPS (certificado autofirmado) y OpenSSH.

### 3. FortiGate (solo por GUI)

| Paso | Ruta en la GUI | Configuración |
|---|---|---|
| Interfaces | Red > Interfaces | `Port1` (lado ISP) y `Port2` (servidor) con sus IPs |
| Ruta por defecto | Red > Rutas estáticas | `0.0.0.0/0` hacia `10.10.52.1` por `Port1` |
| Usuario | Usuario y dispositivo > Definición de usuario | Usuario local `vpnuser` |
| Grupo | Usuario y dispositivo > Grupos de usuarios | `Grupo-VPN` con `vpnuser` |
| VPN SSL | VPN > Configuración de VPN SSL | Interfaz `Port1`, puerto **10443**, rango `<RANGO_VPN>`, grupo `Grupo-VPN` |
| IP virtual | Política y objetos > IP virtuales | `10.10.52.2:443` → `<IP_SERVIDOR>:443` |
| Política web | Política y objetos > Política de firewall | `Port1` → `Port2`, destino la IP virtual, servicio HTTPS |
| Política ICMP | Política y objetos > Política de firewall | `Port1` → `Port2`, servicio ALL_ICMP (traceroute) |
| Política SSH | Política y objetos > Política de firewall | `ssl.root` → `Port2`, origen `Grupo-VPN`, servicio SSH, sin NAT |
| NAT de salida | Política y objetos > Política de firewall | NAT activado en la política hacia `Port1` |

![VPN SSL](imagenes/forti-vpn-ssl.png)
![Políticas](imagenes/forti-politicas.png)

### 4. Cliente (usuario)
Instalar FortiClient para Linux y crear la conexión de VPN SSL hacia `10.10.52.2`, puerto `10443`, usuario `vpnuser`. Comandos de verificación en [`scripts/cliente.txt`](scripts/cliente.txt).

## Pruebas y resultados

| # | Prueba | Comando | Resultado esperado |
|---|---|---|---|
| 1 | DHCP en VLAN 10 | `ip a` | IP dentro de `10.10.10.0/25` |
| 2 | Traceroute al servidor | `traceroute -n 10.10.52.2` | Pasa por R2 y R1 hasta el FortiGate |
| 3 | Web sin VPN | `curl -k https://10.10.52.2` | Responde la página del servidor |
| 4 | SSH sin VPN | `ssh usuario@<IP_SERVIDOR>` | Falla (tiempo agotado) |
| 5 | Conexión VPN | FortiClient | Conectada, IP del rango VPN |
| 6 | SSH con VPN | `ssh usuario@<IP_SERVIDOR>` | Acceso concedido |
| 7 | Evidencia en el FortiGate | Panel > Monitor > Monitor de VPN SSL | Usuario conectado |

![Pruebas](imagenes/pruebas.png)

## Evidencias de configuración

**R2 — interfaces** (subinterfaz VLAN 10 y enlace hacia el ISP):

![R2](imagenes/r2-interfaces.png)

**R1 — interfaces** (enlaces hacia R2 y hacia el FortiGate):

![R1](imagenes/r1-interfaces.png)

**FortiGate — interfaces** (`port1` hacia el ISP y `port2` hacia el servidor):

![FortiGate](imagenes/forti-interfaces.png)

**Usuario — IP recibida por DHCP** (rango /25 de la VLAN 10):

![Usuario](imagenes/usuario-ip-a.png)

## Archivos del repositorio

```
Infraestructura 3/
├── README.md
├── imagenes/            capturas y diagramas
├── scripts/             R1.txt, R2.txt, servidor.sh, cliente.txt
└── running-configs/     R1.txt, R2.txt, fortigate.conf
```

El FortiGate se configuró solo por GUI; su respaldo se exportó desde la propia interfaz (`fortigate.conf`).
