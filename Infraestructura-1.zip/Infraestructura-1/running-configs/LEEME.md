# Running-configs

Archivos finales que deben estar en esta carpeta:

| Archivo | Cómo obtenerlo |
|---|---|
| `fortigate-1.conf` | GUI de FortiGate-1: menú del usuario (arriba a la derecha) > **Configuración > Copia de seguridad**, destino "Equipo local" |
| `fortigate-2.conf` | Lo mismo en FortiGate-2 |
| `r1-running-config.txt` | En R1: `show running-config` |

Antes de subirlos, revisa que no contengan contraseñas ni claves precompartidas en texto claro.
