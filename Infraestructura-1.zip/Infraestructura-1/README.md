# Infraestructura 1 — VPN sitio a sitio entre dos FortiGate

## Video demostrativo

[![Video demostrativo de la Infraestructura 1](https://img.youtube.com/vi/eK3x5rV18D8/maxresdefault.jpg)](https://www.youtube.com/watch?v=eK3x5rV18D8)

▶ **Ver en YouTube:** https://www.youtube.com/watch?v=eK3x5rV18D8

---

**Autor:** Irving Alejandro Cabral · Matrícula 2024-1497 · Seguridad Informática, ITLA

## Contenido

1. [Propósito del laboratorio](#propósito-del-laboratorio)
2. [Topología y diagramas](#topología-y-diagramas)
3. [Plan de direccionamiento](#plan-de-direccionamiento)
4. [Configuración](#configuración)
5. [Verificación y diagnóstico](#verificación-y-diagnóstico)
6. [Pruebas y evidencias](#pruebas-y-evidencias)
7. [Estructura del repositorio](#estructura-del-repositorio)

## Propósito del laboratorio

Demostrar que dos sedes separadas por una red pública (ISP) pueden comunicarse de forma segura mediante una **VPN IPsec sitio a sitio** entre dos FortiGate, configurados y demostrados **por la interfaz gráfica (GUI)**, y comprobar que la comunicación entre el usuario y el servidor web **solo fluye mientras el túnel VPN está activo**.

### Objetivos

- Comunicar el equipo de usuario (VLAN 10, con DHCP) con el servidor web (HTTPS) a través del enlace VPN.
- Comprobar que, sin túnel, no hay comunicación entre las redes privadas, porque el ISP no tiene rutas hacia ellas.
- Configurar redes, NAT y la VPN sitio a sitio entre los dos FortiGate.
- Verificar la ruta con `traceroute` desde el usuario hacia el servidor.

## Topología y diagramas

### Topología en GNS3

![Topología en GNS3](images/topologia-gns3.png)

**Archivo del proyecto:** [`topologia/Semana_3.gns3`](topologia/Semana_3.gns3) (GNS3 2.2.61). Para abrirlo se necesitan las imágenes de FortiGate 7.0.9, Cisco c7200 y una máquina virtual Ubuntu en VMware; la ruta de la VM dentro del archivo debe ajustarse al equipo donde se abra.

### Diagrama lógico

```mermaid
graph TD
    ISP["ISP (R1)<br/>f0/0 10.50.50.2/30<br/>f1/0 192.168.100.2/30"]
    FG1["FortiGate-1"]
    FG2["FortiGate-2"]
    SW["Switch1<br/>VLAN 10"]
    PC["PC1 (usuario)<br/>DHCP"]
    SRV["Servidor Web HTTPS<br/>(Ubuntu)"]

    FG1 ---|"Port1 10.50.50.1/30"| ISP
    ISP ---|"Port1 192.168.100.1/30"| FG2
    FG1 -.-|"Túnel IPsec"| FG2
    FG1 ---|"Port10 · VLAN 10 · 192.168.110.1"| SW
    SW --- PC
    FG2 ---|"Port10 · 10.50.52.1"| SRV
```

### Diagrama de la negociación de la VPN

```mermaid
sequenceDiagram
    participant PC as PC1 (usuario)
    participant F1 as FortiGate-1
    participant ISP as R1 (ISP)
    participant F2 as FortiGate-2
    participant S as Servidor Web

    F1->>F2: Fase 1 (IKE): autenticación con clave precompartida
    F2-->>F1: Fase 1 establecida
    PC->>F1: Tráfico hacia el servidor
    F1->>F2: Fase 2 (IPsec): selectores 192.168.110.0 ↔ 10.50.52.0
    F2-->>F1: Fase 2 establecida (túnel activo)
    Note over ISP: Solo ve paquetes ESP entre IP públicas
    PC->>S: Ping / HTTPS cifrado dentro del túnel
    S-->>PC: Respuesta por el mismo túnel
```

## Plan de direccionamiento

| Segmento | Red | Dispositivo | Interfaz | Dirección |
|---|---|---|---|---|
| FortiGate-1 ↔ ISP | 10.50.50.0/30 | FortiGate-1 | Port1 | 10.50.50.1 |
| | | R1 | f0/0 | 10.50.50.2 |
| ISP ↔ FortiGate-2 | 192.168.100.0/30 | R1 | f1/0 | 192.168.100.2 |
| | | FortiGate-2 | Port1 | 192.168.100.1 |
| Usuarios (VLAN 10) | 192.168.110.0/24 | FortiGate-1 | Port10 · VLAN 10 | 192.168.110.1 (puerta de enlace y servidor DHCP) |
| | | PC1 | e0 | DHCP |
| Servidor | 10.50.52.0/24 | FortiGate-2 | Port10 | 10.50.52.1 (puerta de enlace) |
| | | Servidor Web | ens33 | 10.50.52.10 |

### Conexiones

| Extremo A | Extremo B |
|---|---|
| FortiGate-1 Port1 | R1 f0/0 |
| R1 f1/0 | FortiGate-2 Port1 |
| FortiGate-1 Port10 | Switch1 e0 (troncal dot1q) |
| Switch1 e1 (acceso VLAN 10) | PC1 e0 |
| FortiGate-2 Port10 | Servidor Web |

> El ISP solo conoce sus redes conectadas. No tiene rutas hacia las redes de usuarios ni del servidor, por eso la única vía entre ambas es el túnel.

## Configuración

### ISP (R1)

Script: [`scripts/isp-r1.cfg`](scripts/isp-r1.cfg)

### Switch1 (VLAN 10)

| Puerto | Modo | VLAN |
|---|---|---|
| e0 (hacia FortiGate-1 Port10) | dot1q (troncal) | 10 |
| e1 (hacia PC1) | Acceso | 10 |

### FortiGate-1 (GUI)

1. **Red > Interfaces**
   - `port1`: rol WAN, `10.50.50.1/255.255.255.252`.
   - Interfaz tipo VLAN sobre `port10`: ID 10, rol LAN, IP `192.168.110.1`, **servidor DHCP** activado y **PING** en el acceso administrativo.
2. **Red > Rutas estáticas**: `0.0.0.0/0` por `10.50.50.2`, interfaz `port1`.
3. **VPN > Asistente de IPsec** (plantilla *Sitio a sitio*): par remoto `192.168.100.1`, interfaz `port1`, clave precompartida, subred local `192.168.110.0/24`, subred remota `10.50.52.0/24`.
4. **Política y objetos > Política de firewall**
   - Usuarios → `port1` con **NAT**.
   - Usuarios → túnel y túnel → usuarios **sin NAT**.

### FortiGate-2 (GUI)

1. **Red > Interfaces**: `port1` `192.168.100.1/255.255.255.252` (WAN) y `port10` `10.50.52.1/255.255.255.0` (LAN).
2. **Red > Rutas estáticas**: `0.0.0.0/0` por `192.168.100.2`.
3. **VPN > Asistente de IPsec** (*Sitio a sitio*): par remoto `10.50.50.1`, misma clave, subred local `10.50.52.0/24`, subred remota `192.168.110.0/24`.
4. **Política y objetos > Política de firewall**: servidor → `port1` con NAT, y túnel ↔ servidor sin NAT, permitiendo HTTPS (443) e ICMP.

### Parámetros de la VPN

| Parámetro | Valor |
|---|---|
| Tipo | IPsec sitio a sitio, basada en ruta |
| Fase 1 | IKEv1, AES-256, SHA-256, DH grupo 14 |
| Fase 2 | AES-256, SHA-256, PFS grupo 14 |
| Selectores | 192.168.110.0/24 ↔ 10.50.52.0/24 |
| Autenticación | Clave precompartida |
| Negociación automática | Activada en la fase 2 |

### PC1 y servidor

- PC1: [`scripts/pc1-vpcs.txt`](scripts/pc1-vpcs.txt)
- Red del servidor: [`scripts/servidor-netplan.yaml`](scripts/servidor-netplan.yaml)
- HTTPS del servidor: [`scripts/servidor-https.sh`](scripts/servidor-https.sh)

## Verificación y diagnóstico

Comandos de consulta usados durante el laboratorio (la configuración se hizo por GUI): [`scripts/fortigate-verificacion.txt`](scripts/fortigate-verificacion.txt)

## Pruebas y evidencias

```mermaid
flowchart TD
    A["PC1 obtiene IP por DHCP"] --> B["Túnel activo en Monitor de IPsec"]
    B --> C["ping y traceroute al servidor: responden"]
    C --> D["HTTPS al servidor: carga la página"]
    D --> E["Se desactiva el túnel"]
    E --> F["ping y HTTPS: sin respuesta"]
    F --> G["Se reactiva el túnel: vuelve la comunicación"]
```

| # | Prueba | Resultado esperado | Evidencia |
|---|---|---|---|
| 1 | PC1 obtiene IP por DHCP | Dirección de la VLAN 10 y puerta de enlace del FortiGate-1 | ![DHCP](images/01-dhcp.png) |
| 2 | Estado del túnel en **Monitor > Monitor de IPsec** | Activo en ambos FortiGate | ![Túnel activo](images/02-tunel-activo.png) |
| 3 | `ping` de PC1 al servidor | Respuesta | ![Ping](images/03-ping-ok.png) |
| 4 | `traceroute` de PC1 al servidor | Sin saltos del ISP | ![Traceroute](images/04-traceroute.png) |
| 5 | HTTPS al servidor | Página cargada | ![HTTPS](images/05-https.png) |
| 6 | Túnel desactivado: `ping` y HTTPS | Sin comunicación | ![Sin VPN](images/06-sin-vpn.png) |
| 7 | Túnel reactivado | Comunicación restablecida | ![Restablecido](images/07-restablecido.png) |

## Estructura del repositorio

```
Infraestructura-1/
├── README.md
├── images/
│   └── topologia-gns3.png
├── topologia/
│   └── Semana_3.gns3
├── scripts/
│   ├── isp-r1.cfg
│   ├── pc1-vpcs.txt
│   ├── servidor-netplan.yaml
│   ├── servidor-https.sh
│   └── fortigate-verificacion.txt
└── running-configs/
    ├── fortigate-1.conf
    ├── fortigate-2.conf
    └── r1-running-config.txt
```
